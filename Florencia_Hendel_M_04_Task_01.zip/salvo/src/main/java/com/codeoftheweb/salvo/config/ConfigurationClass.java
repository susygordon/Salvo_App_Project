package com.codeoftheweb.salvo.config;

import com.codeoftheweb.salvo.service.GameService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ConfigurationClass {
    //  @Bean
    // public GameService gameService() {
    //    return new GameService();

    // }

}

