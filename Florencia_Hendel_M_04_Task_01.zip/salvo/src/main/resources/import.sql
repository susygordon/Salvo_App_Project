INSERT INTO PLAYER (ID, FIRST_NAME, LAST_NAME, USERNAME) VALUES (1,'Jack', 'Bauer', 'j.bauer@ctu.gov')
INSERT INTO PLAYER (ID, FIRST_NAME, LAST_NAME, USERNAME) VALUES (2,'Chloe','OBrian', 'c.obrian@ctu.gov')
INSERT INTO PLAYER (ID, FIRST_NAME, LAST_NAME, USERNAME) VALUES (3,'Kim', 'Bauer', 'kim_bauer@gmail.com')
INSERT INTO PLAYER (ID, FIRST_NAME, LAST_NAME, USERNAME) VALUES (4,'Tony', 'Almeida', 't.almeida@ctu.gov')


